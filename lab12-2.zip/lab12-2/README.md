# Secreenshots
![Anonymous](/screenshots/Anonymous%20user.png)
![Super Admin](/screenshots/Super%20admin%20user.png)
![Admin](/screenshots/Admin%20user.png)
![Registrar](/screenshots/Registrar%20user.png)
![Student](/screenshots/Student%20user.png)